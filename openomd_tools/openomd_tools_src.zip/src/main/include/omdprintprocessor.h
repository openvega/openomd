#pragma once
#include <set>
#include <iomanip>
#include <iostream>
#include "openomd/omddef.h"
#include "openomd/omdcparser.h"
#include "openomd/omddparser.h"
#include "openomd/omdccparser.h"
#include "openomd/omdparser.h"
#include "openomd/omdcostream.h"
#include "openomd/omddostream.h"
#include "openomd/omdccostream.h"

namespace openomd
{
template <typename _LineArbitration>
class BasePrintProcessor : public _LineArbitration
{
public:
    using _LineArbitration::_LineArbitration;

    void onHeartbeat()
    {
    }

    void timestamp(struct timeval& ts)
    {
        _ts = ts;
    }

    void onUnknownMessage(uint16_t type, uint16_t msgSize)
    {
        std::cout << "PrintProcessor onUnknownMessage type=" << type << " msgSize=" << msgSize << std::endl;
    }

    void onError(std::exception const& ex)
    {
        std::cout << "PrintProcessor onError " << ex.what() << std::endl;
    }

    inline int32_t channel() const {
        return _channel;
    }
    inline void channel(int32_t channel) {
        _channel = channel;
    }
    void info(std::string const& log) const
    {
        std::cout << log << std::endl;
    }
    void warn(std::string const& log) const
    {
        std::cout << log << std::endl;
    }
    void error(std::string const& log) const
    {
        std::cerr << log << std::endl;
    }

protected:
    
    template <typename _Msg>
    void onPrintMessage(_Msg const& m, uint32_t seqNum)
    {
        //if (_msgIds.find(_Msg::sbeTemplateId()) != _msgIds.end() || _msgIds.find(0) != _msgIds.end())
        {
#ifdef _WIN32
            std::cout << _ts.tv_sec << "." << std::setfill('0') << std::setw(6) << _ts.tv_usec << "," << seqNum << "," << m << std::endl;
#else
            char timeBuffer[32];
            struct tm* timeInfo = localtime(static_cast<time_t*>(& _ts.tv_sec));
            strftime(timeBuffer, sizeof(timeBuffer), "%Y-%m-%d %H:%M:%S", timeInfo);
            std::cout << timeBuffer << "." << std::setfill('0') << std::setw(6) << _ts.tv_usec << "," << seqNum << "," << m << std::endl;
#endif
        }
    }
    std::set<int32_t> _msgIds;
    int32_t _channel;
    struct timeval _ts;
};

template <typename _LineArbitration>
class OmdcPrintProcessor : public BasePrintProcessor<_LineArbitration>
{
public:
    using Base = BasePrintProcessor<_LineArbitration>;
    using Base::BasePrintProcessor;
    using Base::onPrintMessage;

    void onMessage(omdc::sbe::AddOddLotOrder const& m, uint32_t s) { onPrintMessage(m, s); }
    void onMessage(omdc::sbe::AddOrder const& m, uint32_t s) { onPrintMessage(m, s); }
    void onMessage(omdc::sbe::AggregateOrderBookUpdate& m, uint32_t s) { onPrintMessage(m, s); }
    void onMessage(omdc::sbe::BrokerQueue const& m, uint32_t s) { onPrintMessage(m, s); }
    void onMessage(omdc::sbe::ClosingPrice const& m, uint32_t s) { onPrintMessage(m, s); }
    void onMessage(omdc::sbe::CurrencyRate const& m, uint32_t s) { onPrintMessage(m, s); }
    void onMessage(omdc::sbe::DeleteOddLotOrder const& m, uint32_t s) { onPrintMessage(m, s); }
    void onMessage(omdc::sbe::DeleteOrder const& m, uint32_t s) { onPrintMessage(m, s); }
    void onMessage(omdc::sbe::DisasterRecoverySignal const& m, uint32_t s) { onPrintMessage(m, s); }
    void onMessage(omdc::sbe::IndexData const& m, uint32_t s) { onPrintMessage(m, s); }
    void onMessage(omdc::sbe::IndexDefinition const& m, uint32_t s) { onPrintMessage(m, s); }
    void onMessage(omdc::sbe::IndicativeEquilibriumPrice const& m, uint32_t s) { onPrintMessage(m, s); }
    void onMessage(omdc::sbe::LiquidityProvider const& m, uint32_t s) { onPrintMessage(m, s); }
    void onMessage(omdc::sbe::Logon const& m, uint32_t s) { }
    void onMessage(omdc::sbe::LogonResponse const& m, uint32_t s) { }
    void onMessage(omdc::sbe::MarketDefinition const& m, uint32_t s) { onPrintMessage(m, s); }
    void onMessage(omdc::sbe::MarketTurnover const& m, uint32_t s) { onPrintMessage(m, s); }
    void onMessage(omdc::sbe::ModifyOrder const& m, uint32_t s) { onPrintMessage(m, s); }
    void onMessage(omdc::sbe::News const& m, uint32_t s) { onPrintMessage(m, s); }
    void onMessage(omdc::sbe::NominalPrice const& m, uint32_t s) { onPrintMessage(m, s); }
    void onMessage(omdc::sbe::OrderImbalance const& m, uint32_t s) { onPrintMessage(m, s); }
    void onMessage(omdc::sbe::ReferencePrice const& m, uint32_t s) { onPrintMessage(m, s); }
    void onMessage(omdc::sbe::RefreshComplete const& m, uint32_t s) { onPrintMessage(m, s); }
    void onMessage(omdc::sbe::RetransmissionReq const& m, uint32_t s) { }
    void onMessage(omdc::sbe::RetransmissionResp const& m, uint32_t s) { onPrintMessage(m, s); }
    void onMessage(omdc::sbe::SecurityDefinition const& m, uint32_t s) { onPrintMessage(m, s); }
    void onMessage(omdc::sbe::SecurityStatus const& m, uint32_t s) { onPrintMessage(m, s); }
    void onMessage(omdc::sbe::SequenceReset const& m, uint32_t s) { onPrintMessage(m, s); Base::resetSeqNum(m.newSeqNo()); }
    void onMessage(omdc::sbe::Statistics const& m, uint32_t s) { onPrintMessage(m, s); }
    void onMessage(omdc::sbe::StockConnectDailyQuotaBalance const& m, uint32_t s) { onPrintMessage(m, s); }
    void onMessage(omdc::sbe::StockConnectMarketTurnover const& m, uint32_t s) { onPrintMessage(m, s); }
    void onMessage(omdc::sbe::Trade const& m, uint32_t s) { onPrintMessage(m, s); }
    void onMessage(omdc::sbe::TradeCancel const& m, uint32_t s) { onPrintMessage(m, s); }
    void onMessage(omdc::sbe::TradeTicker const& m, uint32_t s) { onPrintMessage(m, s); }
    void onMessage(omdc::sbe::TradingSessionStatus const& m, uint32_t s) { onPrintMessage(m, s); }
    void onMessage(omdc::sbe::VCMTrigger const& m, uint32_t s) { onPrintMessage(m, s); }
    void onMessage(omdc::sbe::Yield const& m, uint32_t s) { onPrintMessage(m, s); }
};

template <typename _LineArbitration>
class OmddPrintProcessor : public BasePrintProcessor<_LineArbitration>
{
public:
    using Base = BasePrintProcessor<_LineArbitration>;
    using Base::BasePrintProcessor;
    using Base::onPrintMessage;

    void onMessage(omdd::sbe::AddOrder const& m, uint32_t s) { onPrintMessage(m, s); }
    void onMessage(omdd::sbe::AggregateOrderBookUpdate& m, uint32_t s) { onPrintMessage(m, s); }
    void onMessage(omdd::sbe::CalculatedOpeningPrice const& m, uint32_t s) { onPrintMessage(m, s); }
    void onMessage(omdd::sbe::ClassDefinition const& m, uint32_t s) { onPrintMessage(m, s); }
    void onMessage(omdd::sbe::CombinationDefinition const& m, uint32_t s) { onPrintMessage(m, s); }
    void onMessage(omdd::sbe::CommodityDefinition const& m, uint32_t s) { onPrintMessage(m, s); }
    void onMessage(omdd::sbe::CommodityStatus const& m, uint32_t s) { onPrintMessage(m, s); }
    void onMessage(omdd::sbe::DeleteOrder const& m, uint32_t s) { onPrintMessage(m, s); }
    void onMessage(omdd::sbe::DisasterRecoverySignal const& m, uint32_t s) { onPrintMessage(m, s); }
    void onMessage(omdd::sbe::EstimatedAverageSettlementPrice const& m, uint32_t s) { onPrintMessage(m, s); }
    void onMessage(omdd::sbe::ImpliedVolatility const& m, uint32_t s) { onPrintMessage(m, s); }
    void onMessage(omdd::sbe::LogonResponse const& m, uint32_t s) { onPrintMessage(m, s); }
    void onMessage(omdd::sbe::MarketAlert const& m, uint32_t s) { onPrintMessage(m, s); }
    void onMessage(omdd::sbe::ModifyOrder const& m, uint32_t s) { onPrintMessage(m, s); }
    void onMessage(omdd::sbe::OpenInterest const& m, uint32_t s) { onPrintMessage(m, s); }
    void onMessage(omdd::sbe::OrderbookClear const& m, uint32_t s) { onPrintMessage(m, s); }
    void onMessage(omdd::sbe::QuoteRequest const& m, uint32_t s) { onPrintMessage(m, s); }
    void onMessage(omdd::sbe::RefreshComplete const& m, uint32_t s) { onPrintMessage(m, s); }
    void onMessage(omdd::sbe::RetransmissionResponse const& m, uint32_t s) { onPrintMessage(m, s); }
    void onMessage(omdd::sbe::SequenceReset const& m, uint32_t s) { onPrintMessage(m, s); Base::resetSeqNum(m.newSeqNo());}
    void onMessage(omdd::sbe::SeriesDefinitionBase const& m, uint32_t s) { onPrintMessage(m, s); }
    void onMessage(omdd::sbe::SeriesDefinitionExtended const& m, uint32_t s) { onPrintMessage(m, s); }
    void onMessage(omdd::sbe::SeriesStatistics const& m, uint32_t s) { onPrintMessage(m, s); }
    void onMessage(omdd::sbe::SeriesStatus const& m, uint32_t s) { onPrintMessage(m, s); }
    void onMessage(omdd::sbe::Trade const& m, uint32_t s) { onPrintMessage(m, s); }
    void onMessage(omdd::sbe::TradeAmendment const& m, uint32_t s) { onPrintMessage(m, s); }
    void onMessage(omdd::sbe::TradeStatistics const& m, uint32_t s) { onPrintMessage(m, s); }
    void onMessage(omdd::sbe::MarketStatus const& m, uint32_t s) { onPrintMessage(m, s); }
};

template <typename _LineArbitration>
class OmdPrintProcessor : public BasePrintProcessor<_LineArbitration>
{
public:
    using Base = BasePrintProcessor<_LineArbitration>;
    using Base::BasePrintProcessor;
    using Base::onPrintMessage;

    void onMessage(omdc::sbe::AddOddLotOrder const& m, uint32_t s) { onPrintMessage(m, s); }
    void onMessage(omdc::sbe::AddOrder const& m, uint32_t s) { onPrintMessage(m, s); }
    void onMessage(omdc::sbe::AggregateOrderBookUpdate& m, uint32_t s) { onPrintMessage(m, s); }
    void onMessage(omdc::sbe::BrokerQueue const& m, uint32_t s) { onPrintMessage(m, s); }
    void onMessage(omdc::sbe::ClosingPrice const& m, uint32_t s) { onPrintMessage(m, s); }
    void onMessage(omdc::sbe::CurrencyRate const& m, uint32_t s) { onPrintMessage(m, s); }
    void onMessage(omdc::sbe::DeleteOddLotOrder const& m, uint32_t s) { onPrintMessage(m, s); }
    void onMessage(omdc::sbe::DeleteOrder const& m, uint32_t s) { onPrintMessage(m, s); }
    void onMessage(omdc::sbe::DisasterRecoverySignal const& m, uint32_t s) { onPrintMessage(m, s); }
    void onMessage(omdc::sbe::IndexData const& m, uint32_t s) { onPrintMessage(m, s); }
    void onMessage(omdc::sbe::IndexDefinition const& m, uint32_t s) { onPrintMessage(m, s); }
    void onMessage(omdc::sbe::IndicativeEquilibriumPrice const& m, uint32_t s) { onPrintMessage(m, s); }
    void onMessage(omdc::sbe::LiquidityProvider const& m, uint32_t s) { onPrintMessage(m, s); }
    void onMessage(omdc::sbe::Logon const& m, uint32_t s) {}
    void onMessage(omdc::sbe::LogonResponse const& m, uint32_t s) {}
    void onMessage(omdc::sbe::MarketDefinition const& m, uint32_t s) { onPrintMessage(m, s); }
    void onMessage(omdc::sbe::MarketTurnover const& m, uint32_t s) { onPrintMessage(m, s); }
    void onMessage(omdc::sbe::ModifyOrder const& m, uint32_t s) { onPrintMessage(m, s); }
    void onMessage(omdc::sbe::News const& m, uint32_t s) { onPrintMessage(m, s); }
    void onMessage(omdc::sbe::NominalPrice const& m, uint32_t s) { onPrintMessage(m, s); }
    void onMessage(omdc::sbe::OrderImbalance const& m, uint32_t s) { onPrintMessage(m, s); }
    void onMessage(omdc::sbe::ReferencePrice const& m, uint32_t s) { onPrintMessage(m, s); }
    void onMessage(omdc::sbe::RefreshComplete const& m, uint32_t s) { onPrintMessage(m, s); }
    void onMessage(omdc::sbe::RetransmissionReq const& m, uint32_t s) {}
    void onMessage(omdc::sbe::RetransmissionResp const& m, uint32_t s) { onPrintMessage(m, s); }
    void onMessage(omdc::sbe::SecurityDefinition const& m, uint32_t s) { onPrintMessage(m, s); }
    void onMessage(omdc::sbe::SecurityStatus const& m, uint32_t s) { onPrintMessage(m, s); }
    void onMessage(omdc::sbe::SequenceReset const& m, uint32_t s) { onPrintMessage(m, s); Base::resetSeqNum(m.newSeqNo()); }
    void onMessage(omdc::sbe::Statistics const& m, uint32_t s) { onPrintMessage(m, s); }
    void onMessage(omdc::sbe::StockConnectDailyQuotaBalance const& m, uint32_t s) { onPrintMessage(m, s); }
    void onMessage(omdc::sbe::StockConnectMarketTurnover const& m, uint32_t s) { onPrintMessage(m, s); }
    void onMessage(omdc::sbe::Trade const& m, uint32_t s) { onPrintMessage(m, s); }
    void onMessage(omdc::sbe::TradeCancel const& m, uint32_t s) { onPrintMessage(m, s); }
    void onMessage(omdc::sbe::TradeTicker const& m, uint32_t s) { onPrintMessage(m, s); }
    void onMessage(omdc::sbe::TradingSessionStatus const& m, uint32_t s) { onPrintMessage(m, s); }
    void onMessage(omdc::sbe::VCMTrigger const& m, uint32_t s) { onPrintMessage(m, s); }
    void onMessage(omdc::sbe::Yield const& m, uint32_t s) { onPrintMessage(m, s); }

    void onMessage(omdd::sbe::AddOrder const& m, uint32_t s) { onPrintMessage(m, s); }
    void onMessage(omdd::sbe::AggregateOrderBookUpdate& m, uint32_t s) { onPrintMessage(m, s); }
    void onMessage(omdd::sbe::CalculatedOpeningPrice const& m, uint32_t s) { onPrintMessage(m, s); }
    void onMessage(omdd::sbe::ClassDefinition const& m, uint32_t s) { onPrintMessage(m, s); }
    void onMessage(omdd::sbe::CombinationDefinition const& m, uint32_t s) { onPrintMessage(m, s); }
    void onMessage(omdd::sbe::CommodityDefinition const& m, uint32_t s) { onPrintMessage(m, s); }
    void onMessage(omdd::sbe::CommodityStatus const& m, uint32_t s) { onPrintMessage(m, s); }
    void onMessage(omdd::sbe::DeleteOrder const& m, uint32_t s) { onPrintMessage(m, s); }
    void onMessage(omdd::sbe::DisasterRecoverySignal const& m, uint32_t s) { onPrintMessage(m, s); }
    void onMessage(omdd::sbe::EstimatedAverageSettlementPrice const& m, uint32_t s) { onPrintMessage(m, s); }
    void onMessage(omdd::sbe::ImpliedVolatility const& m, uint32_t s) { onPrintMessage(m, s); }
    void onMessage(omdd::sbe::LogonResponse const& m, uint32_t s) { onPrintMessage(m, s); }
    void onMessage(omdd::sbe::MarketAlert const& m, uint32_t s) { onPrintMessage(m, s); }
    void onMessage(omdd::sbe::ModifyOrder const& m, uint32_t s) { onPrintMessage(m, s); }
    void onMessage(omdd::sbe::OpenInterest const& m, uint32_t s) { onPrintMessage(m, s); }
    void onMessage(omdd::sbe::OrderbookClear const& m, uint32_t s) { onPrintMessage(m, s); }
    void onMessage(omdd::sbe::QuoteRequest const& m, uint32_t s) { onPrintMessage(m, s); }
    void onMessage(omdd::sbe::RefreshComplete const& m, uint32_t s) { onPrintMessage(m, s); }
    void onMessage(omdd::sbe::RetransmissionResponse const& m, uint32_t s) { onPrintMessage(m, s); }
    void onMessage(omdd::sbe::SequenceReset const& m, uint32_t s) { onPrintMessage(m, s); Base::resetSeqNum(m.newSeqNo()); }
    void onMessage(omdd::sbe::SeriesDefinitionBase const& m, uint32_t s) { onPrintMessage(m, s); }
    void onMessage(omdd::sbe::SeriesDefinitionExtended const& m, uint32_t s) { onPrintMessage(m, s); }
    void onMessage(omdd::sbe::SeriesStatistics const& m, uint32_t s) { onPrintMessage(m, s); }
    void onMessage(omdd::sbe::SeriesStatus const& m, uint32_t s) { onPrintMessage(m, s); }
    void onMessage(omdd::sbe::Trade const& m, uint32_t s) { onPrintMessage(m, s); }
    void onMessage(omdd::sbe::TradeAmendment const& m, uint32_t s) { onPrintMessage(m, s); }
    void onMessage(omdd::sbe::TradeStatistics const& m, uint32_t s) { onPrintMessage(m, s); }
    void onMessage(omdd::sbe::MarketStatus const& m, uint32_t s) { onPrintMessage(m, s); }
};

template <typename _LineArbitration>
class OmdccPrintProcessor : public BasePrintProcessor<_LineArbitration>
{
public:
    using Base = BasePrintProcessor<_LineArbitration>;
    using Base::BasePrintProcessor;
    using Base::onPrintMessage;

    void onMessage(omdcc::sbe::DisasterRecoverySignal const& m, uint32_t s) { onPrintMessage(m, s); }
    void onMessage(omdcc::sbe::Logon const& m, uint32_t s) { }
    void onMessage(omdcc::sbe::LogonResponse const& m, uint32_t s) { }
    void onMessage(omdcc::sbe::MarketDefinition const& m, uint32_t s) { onPrintMessage(m, s); }
    void onMessage(omdcc::sbe::RefreshComplete const& m, uint32_t s) { onPrintMessage(m, s); }
    void onMessage(omdcc::sbe::RetransmissionReq const& m, uint32_t s) { }
    void onMessage(omdcc::sbe::RetransmissionResp const& m, uint32_t s) { }
    void onMessage(omdcc::sbe::SecurityDefinition const& m, uint32_t s) { onPrintMessage(m, s); }
    void onMessage(omdcc::sbe::SecurityStatus const& m, uint32_t s) { onPrintMessage(m, s); }
    void onMessage(omdcc::sbe::SequenceReset const& m, uint32_t s) { onPrintMessage(m, s); Base::resetSeqNum(m.newSeqNo()); }
    void onMessage(omdcc::sbe::Statistics const& m, uint32_t s) { onPrintMessage(m, s); }
    void onMessage(omdcc::sbe::TopOfBook const& m, uint32_t s) { onPrintMessage(m, s); }

};
}
